package com.example.newproject.vm


import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.newproject.MainActivity
import com.example.newproject.data.Movie
import com.example.newproject.data.MovieResponseImages
import com.example.newproject.repository.MovieRepositoryImpl
import com.example.newproject.repository.MovieRepositoty
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class MovieViewModel:ViewModel() {
    private val _currentMovie = MutableStateFlow<Movie?>(null)

    private val _currentMovie_: MutableLiveData<MovieResponseImages?> = MutableLiveData(null)
    private val repositoty: MovieRepositoty = MovieRepositoryImpl()
    val currentMovie: StateFlow<Movie?> = _currentMovie
    fun loadMovie(movieId: Long){
        viewModelScope.launch(Dispatchers.IO){
            val movie = repositoty.getMovieDetails(movieId)
            _currentMovie.value = movie
        }

    }



    private val callbackimages: MovieRepositoty.callbackimages = object : MovieRepositoty.callbackimages{
        override fun onMovieLoaded(movie: MovieResponseImages?) {
            if (movie != null) {
                _currentMovie_.value = movie
                Log.i(MainActivity.TAG,"Callbackimages -> $movie")
            }
        }

    }
    val currentMovie1: MutableLiveData<MovieResponseImages?> = _currentMovie_


    fun loadMovieImage(movieId: Long){
        repositoty.getMovieImage(movieId,callbackimages, MovieRepositoty.MovieApi)
    }

}