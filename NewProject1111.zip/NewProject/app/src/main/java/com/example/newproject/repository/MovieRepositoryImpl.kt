package com.example.newproject.repository
import android.util.Log
import com.example.newproject.MainActivity
import com.example.newproject.data.Movie
import com.example.newproject.data.MovieResponseImages
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MovieRepositoryImpl: MovieRepositoty {
    override suspend fun getMovieDetails(movieId: Long): Movie? {
        val response = MovieRepositoty.MovieApi.INSTANCE.getMovieDetails(movieId, API_KEY).execute()
return if(response.isSuccessful)response.body() else null
    }

    override fun getMovieImage(
        movieId: Long,
        callback: MovieRepositoty.callbackimages,
        MovieApi: MovieRepositoty.MovieApi.Companion
    ) {
        MovieApi.INSTANCE.getMovieImages(movieId, API_KEY).enqueue(object :Callback<MovieResponseImages>{
            override fun onResponse(call: Call<MovieResponseImages>, response: Response<MovieResponseImages>) {
                if (response.isSuccessful){
                    callback.onMovieLoaded(response.body())
                }else {
                    callback.onMovieLoaded(null)
                }
                Log.i(MainActivity.TAG,"getMovieImages")
            }

            override fun onFailure(call: Call<MovieResponseImages>, t: Throwable) {
                callback.onMovieLoaded(null)
            }

        })
    }

    companion object {
        const val API_KEY = "95d291306c05c68fb2617a17182a102b"
        const val TAG = "MovieRepositoryImpl"
    }

}



