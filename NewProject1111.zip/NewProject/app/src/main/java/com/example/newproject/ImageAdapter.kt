package com.example.newproject

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.newproject.data.Images

class ImageAdapter(
    private val context: Context,
    private val dataSet: List<Images>
):RecyclerView.Adapter<ImageAdapter.ItemViewHolder>() {

    class ItemViewHolder(private val view: View): RecyclerView.ViewHolder(view){
        val imgesString: TextView = view.findViewById(R.id.text_images_view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val view = LayoutInflater
            .from(parent.context)
            .inflate(R.layout.text_images,parent,false)
        return ItemViewHolder(view)
    }

    override fun getItemCount(): Int {
        return dataSet.size
    }
    data class data_Set (val stringResourceId: Int){}

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val data_set = dataSet[position]
        /*holder.imgesString.text = context.resources.getString(data_set.file_path.length)*/
        holder.itemView.findViewById<TextView>(R.id.text_images_view).text = data_set.file_path[position].toString()
    }
}


