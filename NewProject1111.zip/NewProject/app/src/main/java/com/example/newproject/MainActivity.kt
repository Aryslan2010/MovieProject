package com.example.newproject

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.bumptech.glide.Glide
import com.example.newproject.data.Movie
import com.example.newproject.data.MovieResponseImages
import com.example.newproject.vm.MovieViewModel
import kotlinx.coroutines.launch


val listImage: MutableList<String> = mutableListOf()

class MainActivity : AppCompatActivity() {
    private val movieIdEdit: EditText by lazy { findViewById(R.id.movie_id_edit)}
    private val loadButton: Button by lazy { findViewById(R.id.load_button)}

    private val movieTitle: TextView by lazy { findViewById(R.id.movie_title_value)}
    private val movieRelease: TextView by lazy { findViewById(R.id.movie_release_value)}
    private val movieBudget: TextView by lazy { findViewById(R.id.movie_budget_value)}

    private val moviePoster: ImageView by lazy {findViewById(R.id.movie_poster) }

    private val DownloadButton: Button by lazy { findViewById(R.id.download_button)}

    private fun SetMovieImage(movie: MovieResponseImages?) {
        if (movie != null) {
            for (i in movie.backdrops.indices){
                listImage.add(movie.backdrops[i].file_path)
            }
            }

    }

    private fun SetMovie (movie: Movie?){
        if (movie == null){return}
        Log.i(TAG,"Movie arrived -> $movie")
        movieTitle.text  = movie.title
        movieRelease.text  = movie.releaseData
        movieBudget.text  = movie.budget.toString()

        Glide.with(this)
            .load(Uri.parse("https://image.tmdb.org/t/p/original/${movie.poster}"))
            .fitCenter()
            .into(moviePoster)

    }






    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d(TAG,"Activity -> OnCreate()")
        val viewModel: MovieViewModel by viewModels()
    lifecycleScope.launch {
        repeatOnLifecycle(Lifecycle.State.STARTED){
            viewModel.currentMovie.collect{movie ->
                SetMovie(movie)

            }
        }
    }
        loadButton.setOnClickListener{
            val movieId = movieIdEdit.text.toString().toLongOrNull()
            if(movieId != null){
                viewModel.loadMovie(movieId)
                //viewModel2.loadMovieImage(movieId)
            }
        }

    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG,"Activity -> onStart()")

        val viewModel2: MovieViewModel by viewModels()

        viewModel2.currentMovie1.observe(this) { movie -> SetMovieImage(movie) }

        DownloadButton.setOnClickListener{

            val movieId = movieIdEdit.text.toString().toLongOrNull()
            if(movieId != null){
            val intent = Intent(this,ImagesActivity::class.java)
                val stingimage = listImage.toString()
                val elementsList = stingimage
                    .trim('[', ']')
                    .split(", ")
            intent.putStringArrayListExtra("listDownload",ArrayList(elementsList))
            startActivity(intent)
            }
            else Toast.makeText(applicationContext,"Вы не ввели moveId",Toast.LENGTH_SHORT).show()
        }
        }
    companion object {
        const val TAG = "MainActivity"
    }
}





